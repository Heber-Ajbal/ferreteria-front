<template>
  <header class="sticky top-0 z-50">
    <!-- Fondo con gradiente -->
    <div class="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 opacity-95 rounded-b-3xl shadow-2xl"></div>

    <div class="relative mx-auto max-w-7xl px-4">
      <FwbNavbar :show="mobileMenuOpen" class="!bg-transparent !px-0 !py-4">
        <!-- LOGO -->
        <template #logo>
          <FwbNavbarLogo href="/" @click.prevent="go('/')" class="group">
            <div class="flex items-center gap-3">
              <div class="w-16 h-16 bg-gradient-to-br from-orange-400 via-amber-400 to-yellow-300 rounded-3xl flex items-center justify-center shadow-2xl transform group-hover:scale-125 group-hover:rotate-6 transition-all duration-500">
                <span class="text-3xl sm:text-4xl text-white drop-shadow-lg">🛠️</span>
              </div>
              <div class="flex flex-col">
                <span class="text-3xl sm:text-5xl font-extrabold bg-gradient-to-r from-amber-300 via-orange-300 to-yellow-200 bg-clip-text text-transparent drop-shadow-xl">
                  MI FERRETERÍA
                </span>
              </div>
            </div>
          </FwbNavbarLogo>
        </template>

        <!-- NAV Desktop y Mobile -->
        <template #default="{ toggle }">
          <!-- Desktop -->
          <div class="hidden lg:flex items-center gap-4">
            <NavItem to="/" icon="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" text="Inicio" gradient="amber"/>
            <NavItem to="/products" icon="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9H9V9h10v2zm-4 4H9v-2h6v2zm4-8H9V5h10v2z" textColor="orange"/>
            <NavItem to="/auth/login" icon="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" gradient="blue" text="Login"/>
            <NavItemCart :count="count"/>
          </div>

          <!-- Mobile hamburger -->
          <button @click="mobileMenuOpen = !mobileMenuOpen" class="lg:hidden p-2 rounded-md text-white hover:bg-slate-700 transition">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
        </template>
      </FwbNavbar>
    </div>
  </header>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useCartStore } from "../stores/cart";
import { storeToRefs } from "pinia";
import { FwbNavbar, FwbNavbarLogo } from "flowbite-vue";

const router = useRouter();
const cart = useCartStore();
const { count } = storeToRefs(cart);

const mobileMenuOpen = ref(false);

function go(path: string) {
  router.push(path);
}

// Componente NavItem reutilizable
const NavItem = defineProps({
  to: String,
  icon: String,
  gradient: String,
  text: String,
  textColor: { type: String, default: "white" },
});
</script>
